"""MLflow experiment tracking + data drift analysis (Diabetes progression use case)."""
import os, json
import numpy as np, pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import mlflow
from scipy.stats import ks_2samp
from sklearn.datasets import load_diabetes
from sklearn.linear_model import Ridge
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split

SEED, ALPHA, PSI_T = 42, 0.05, 0.2
os.makedirs("reports", exist_ok=True)

def psi(ref, cur, bins=10):
    edges = np.quantile(ref, np.linspace(0, 1, bins + 1))
    edges[0], edges[-1] = -np.inf, np.inf
    r = np.histogram(ref, edges)[0] / len(ref)
    c = np.histogram(cur, edges)[0] / len(cur)
    r, c = np.clip(r, 1e-6, None), np.clip(c, 1e-6, None)
    return float(np.sum((c - r) * np.log(c / r)))

# ---- data ----
data = load_diabetes(as_frame=True)
X, y = data.data, data.target
X_ref, X_cur, y_ref, y_cur = train_test_split(X, y, test_size=0.4, random_state=SEED)
X_cur = X_cur.copy()
rng = np.random.default_rng(SEED)
# simulated drift: shift/scale selected features in the "current" (production) data
X_cur["bmi"] += 0.06
X_cur["bp"] += 0.05
X_cur["s5"] *= 1.5
X_cur["age"] += rng.normal(0, 0.005, len(X_cur))   # negligible change

# ---- MLflow tracking ----
mlflow.set_tracking_uri("sqlite:///mlflow.db")
mlflow.set_experiment("diabetes-drift-monitoring")
params = dict(alpha=1.0)
with mlflow.start_run(run_name="ridge-baseline-and-drift"):
    model = Ridge(**params).fit(X_ref, y_ref)
    mlflow.log_params(params)
    mlflow.log_param("dataset", "sklearn diabetes (442 rows)")
    for name, Xs, ys in [("reference", X_ref, y_ref), ("current", X_cur, y_cur)]:
        p = model.predict(Xs)
        mlflow.log_metric(f"{name}_rmse", float(np.sqrt(mean_squared_error(ys, p))))
        mlflow.log_metric(f"{name}_mae", float(mean_absolute_error(ys, p)))
        mlflow.log_metric(f"{name}_r2", float(r2_score(ys, p)))
    mlflow.sklearn.log_model(model, name="model")

    # ---- drift detection ----
    rows = []
    for col in X.columns:
        ks = ks_2samp(X_ref[col], X_cur[col])
        p_ = psi(X_ref[col].values, X_cur[col].values)
        rows.append(dict(feature=col, ks_stat=ks.statistic, p_value=ks.pvalue, psi=p_,
                         drift=bool(ks.pvalue < ALPHA or p_ > PSI_T)))
    df = pd.DataFrame(rows)
    df.to_csv("reports/drift_report.csv", index=False)
    n = int(df.drift.sum())
    mlflow.log_metric("drifted_features", n)
    mlflow.log_metric("drift_share", n / len(df))
    # prediction drift
    pk = ks_2samp(model.predict(X_ref), model.predict(X_cur))
    mlflow.log_metric("prediction_ks_stat", float(pk.statistic))
    mlflow.log_metric("prediction_ks_pvalue", float(pk.pvalue))

    # plots
    fig, axs = plt.subplots(1, 4, figsize=(16, 3.4))
    for ax, c in zip(axs, ["bmi", "bp", "s5", "age"]):
        ax.hist(X_ref[c], bins=25, alpha=.6, label="Reference", density=True)
        ax.hist(X_cur[c], bins=25, alpha=.6, label="Current", density=True)
        ax.set_title(c); ax.legend(fontsize=7)
    plt.tight_layout(); plt.savefig("reports/feature_distributions.png", dpi=130); plt.close()
    plt.figure(figsize=(7, 3.6))
    plt.bar(df.feature, df.psi, color=["tab:red" if d else "tab:green" for d in df.drift])
    plt.axhline(PSI_T, ls="--", c="k"); plt.ylabel("PSI"); plt.title("PSI per feature (red = drift)")
    plt.tight_layout(); plt.savefig("reports/psi_per_feature.png", dpi=130); plt.close()
    mlflow.log_artifacts("reports")
    print(df.round(4).to_string(index=False))
    print("drifted:", n, "/", len(df))
    print("prediction KS:", round(pk.statistic, 4), "p=", pk.pvalue)
    run = mlflow.active_run().info.run_id
    print("run_id", run)
    print(json.dumps(mlflow.get_run(run).data.metrics, indent=1))
