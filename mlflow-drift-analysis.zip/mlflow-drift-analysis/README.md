# MLflow Experiment Tracking and Data Drift Analysis (Diabetes Progression)

Tracks a Ridge regression model with MLflow and detects simulated data drift
(KS test + PSI) between reference and current data.

## Run (Windows cmd)
    python -m venv venv
    venv\Scripts\activate
    pip install -r requirements.txt
    python drift_analysis.py
    mlflow ui --backend-store-uri sqlite:///mlflow.db
Open http://127.0.0.1:5000 and view experiment `diabetes-drift-monitoring`.

## Outputs
- `reports/drift_report.csv`, `reports/feature_distributions.png`, `reports/psi_per_feature.png`
- MLflow run: params, metrics (RMSE/MAE/R2, drifted_features, drift_share, prediction KS), model and reports as artifacts
